$(function(){
	//appendSrcJs(Type.CSS,"../../css/comet4j.cs");
});
//类型
var Type={JS:0,CSS:1};
function appendSrcJs (type,srcVal) {
	var bodyElement = document.getElementsByTagName("body")[0];
	var createElments = null;
	switch (type) {
		case 0:
			var typeElement = "text/javascript";
			createElments = createElment("script");
			setElmentAttribute(createElments,"type",typeElement);
			setElmentAttribute(createElments,"src",srcVal);
			break;
		default:
			var typeElement = "text/css";
			createElments = createElment("link");
			setElmentAttribute(createElments,"type",typeElement);
			setElmentAttribute(createElments,"href",srcVal);
			setElmentAttribute(createElments,"rel","stylesheet");
			break;
	}
	bodyElement.appendChild(createElments);
}
//创建节点
var createElment = function(name){
	return document.createElement(name);
};
//设置属性
var setElmentAttribute = function(element,name,val) {
	element.setAttribute(name, val);
};
if(jQuery) {
	(function($){
		$.messageDialog = function(titleName,comtent,hrefCallBack) {
			var divElement = document.getElementById("tip");
			if(divElement != null && divElement != '' && typeof(divElement) != 'undefined') {
				divElement.remove();
			}
			var divTip = document.createElement("div");
			divTip.id = "tip";
			divTip.innerHTML = "<h1><a href='javascript:void(0)' onclick='start()'>×</a>"+titleName+"</h1><p><a href='javascript:void(0)' id='showwin'>"+comtent+"</a></p>";
			divTip.style.height = '0px';
			divTip.style.bottom = '0px';
			divTip.style.position = 'fixed';
			document.body.appendChild(divTip);
			var showwinElement =  document.getElementById("showwin");
			start();
			showwinElement.onclick = function(){
				showwin(hrefCallBack);
			};
		},
		$.callBackFun = function(callBackStr){
			if(callBackStr != null && callBackStr != '' && callBackStr != 'undefined') {
				callBackStr = callBackStr+"";
				if(callBackStr.indexOf("()") == -1) {
					eval(callBackStr+"()");
				}else{
					eval(callBackStr);
				}
			}
		};
	}(jQuery));
	
}
var formatNumber = function(obj){
	if(obj == null || obj == '' || typeof(obj) == 'undefined') {
		return 0;
	}
	return obj;
};

var handle;
function start(count) {
	var obj = document.getElementById("tip");
	if (parseInt(obj.style.height) == 0) {
		obj.style.display = "block";
		handle = setInterval("changeH('up')", 20);
	} else {
		handle = setInterval("changeH('down')", 20);
	}
};
function changeH(str) {
	var obj = document.all ? document.all["tip"] : document.getElementById("tip");
	if (str == "up") {
		if (parseInt(obj.style.height) > 200)
			clearInterval(handle);
		else
			obj.style.height = (parseInt(obj.style.height) + 8).toString()+ "px";
	}
	if (str == "down") {
		if (parseInt(obj.style.height) < 8) {
			clearInterval(handle);
			obj.style.display = "none";
		} else
			obj.style.height = (parseInt(obj.style.height) - 8).toString()+ "px";
	}
}
function showwin(hrefCallBack) {
	document.getElementsByTagName("html")[0].style.overflow = "hidden";
	start();
	hrefCallBack();
}