/**
 * @Description: 
 * @ClassName: com.omar.controller.LoginController
 * @author: Omar(OmarZhang)
 * @date: 2015年12月2日 下午6:08:49 
 */
package com.omar.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.omar.util.pushmsg.PushMessageUtil;

/**
 * @Description: 
 * @ClassName: com.omar.controller.LoginController
 * @author: Omar(OmarZhang)
 * @date: 2015年12月2日 下午6:08:49 
 *
 */

@Controller("LoginController")
@RequestMapping("/admin/login")
public class LoginController {
	
	@RequestMapping(value="/saveCurrentId",method=RequestMethod.POST)
	public String saveCurrentId(HttpServletRequest request,String currentId) {
		if(StringUtils.isBlank(currentId)) {
			return "/login/index";
		}
		request.getSession().setAttribute("userId", currentId);
		return "/login/main";
	}
	
	@RequestMapping(value="/sendMsgToPerson",method=RequestMethod.POST)
	public String sendMsgToPerson(HttpServletRequest request,String sendToId,String content) {
		String currentId = (String) request.getSession().getAttribute(PushMessageUtil.DEFAULT_MARK);
		if(StringUtils.isBlank(sendToId)) {
			PushMessageUtil.sendMessageToOneCallBack(currentId,"showMessage", "指定发送人信息不能为Null", "clickEvent");
		}else{
			PushMessageUtil.sendMessageToOneCallBack(sendToId,"showMessage", "["+currentId+"] 向你发送:["+content+"]", "clickEvent");
		}
		return "/login/main";
	}
	
}
